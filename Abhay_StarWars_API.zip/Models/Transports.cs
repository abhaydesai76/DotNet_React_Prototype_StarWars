﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace StarWars_API.Models
{
    public partial class Transports
    {
        [Key]
        public int Id { get; set; }
        public string Cargo_Capacity { get; set; }
        public string Consumables { get; set; }
        public string Cost_In_Credits { get; set; }
        public DateTime? Created { get; set; }
        public string Crew { get; set; }
        public DateTime? Edited { get; set; }
        public string Length { get; set; }
        public string Manufacturer { get; set; }
        public string Max_Atmosphering_Speed { get; set; }
        public string Model { get; set; }
        public string Name { get; set; }
        public string Passengers { get; set; }
    }
}
