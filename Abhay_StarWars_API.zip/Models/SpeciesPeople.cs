﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace StarWars_API.Models
{
    public partial class SpeciesPeople
    {
        [Key]
        public int Species_Id { get; set; }
        public int People_Id { get; set; }

        public virtual People People { get; set; }
        public virtual Species Species { get; set; }
    }
}
