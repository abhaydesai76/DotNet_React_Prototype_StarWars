﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StarWars_API.Models
{
    public partial class Film
    {
        public Film()
        {
            FilmsCharacters = new HashSet<FilmsCharacters>();
            FilmsPlanets = new HashSet<FilmsPlanets>();
            FilmsSpecies = new HashSet<FilmsSpecies>();
            FilmsStarships = new HashSet<FilmsStarships>();
            FilmsVehicles = new HashSet<FilmsVehicles>();
        }

        [Key]
        public int Id { get; set; }
        public DateTime? Created { get; set; }
        public string Director { get; set; }
        public DateTime? Edited { get; set; }
        public int? Episode_Id { get; set; }
        public string Opening_Crawl { get; set; }
        public string Producer { get; set; }
        public DateTime? Release_Date { get; set; }
        public string Title { get; set; }

        public virtual ICollection<FilmsCharacters> FilmsCharacters { get; set; }
        public virtual ICollection<FilmsPlanets> FilmsPlanets { get; set; }
        public virtual ICollection<FilmsSpecies> FilmsSpecies { get; set; }
        public virtual ICollection<FilmsStarships> FilmsStarships { get; set; }
        public virtual ICollection<FilmsVehicles> FilmsVehicles { get; set; }
    }
}
