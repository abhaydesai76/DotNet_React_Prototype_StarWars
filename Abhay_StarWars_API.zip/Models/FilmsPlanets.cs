﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StarWars_API.Models
{
    public partial class FilmsPlanets
    {
        [Key]
        public int Film_Id { get; set; }
        public int Planet_Id { get; set; }

        public virtual Film Film { get; set; }
        public virtual Planets Planet { get; set; }
    }
}
