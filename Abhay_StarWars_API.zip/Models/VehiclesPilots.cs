﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StarWars_API.Models
{
    public partial class VehiclesPilots
    {
        [Key]
        public int Vehicle_Id { get; set; }
        public int People_Id { get; set; }

        public virtual People People { get; set; }
        public virtual Vehicles Vehicle { get; set; }
    }
}
