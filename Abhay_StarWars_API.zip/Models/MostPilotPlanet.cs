﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace StarWars_API.Models
{
    public class MostPilotPlanet
    {
        public MostPilotPlanet()
        {
        }

        [Key]
        public int PlanetId { get; set; }
        public string PlanetName { get; set; }
        public int NoOfPilots { get; set; }
        public string PilotName { get; set; }      
        public string SpeciesName { get; set; }
    }
}
