﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace StarWars_API.Models
{
    public class CharacterMaximumAppearance
    {
        public CharacterMaximumAppearance()
        {
        }

        [Key]       
        public string CharacterName { get; set; }
        public int NoOfAppearnces { get; set; }

    }
}
