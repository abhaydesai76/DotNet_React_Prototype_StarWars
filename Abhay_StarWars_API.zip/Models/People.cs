﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace StarWars_API.Models
{
    public partial class People
    {
        public People()
        {
            FilmsCharacters = new HashSet<FilmsCharacters>();
            SpeciesPeople = new HashSet<SpeciesPeople>();
            StarshipsPilots = new HashSet<StarshipsPilots>();
            VehiclesPilots = new HashSet<VehiclesPilots>();
        }

        [Key]
        public int Id { get; set; }
        public string Birth_Year { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Edited { get; set; }
        public string Eye_Color { get; set; }
        public string Gender { get; set; }
        public string Hair_Color { get; set; }
        public string Height { get; set; }
        public int? Homeworld { get; set; }
        public string Mass { get; set; }
        public string Name { get; set; }
        public string Skin_Color { get; set; }

        public virtual ICollection<FilmsCharacters> FilmsCharacters { get; set; }
        public virtual ICollection<SpeciesPeople> SpeciesPeople { get; set; }
        public virtual ICollection<StarshipsPilots> StarshipsPilots { get; set; }
        public virtual ICollection<VehiclesPilots> VehiclesPilots { get; set; }
    }
}
