﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace StarWars_API.Models
{
    public class SpeciesMaximumAppearance
    {
        public SpeciesMaximumAppearance()
        {
        }

        [Key]
        public int SpeciesId { get; set; }
        public string SpeciesName { get; set; }
        public int NoOfAppearnces { get; set; }
    }
}
