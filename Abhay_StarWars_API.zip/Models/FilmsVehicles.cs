﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace StarWars_API.Models
{
    public partial class FilmsVehicles
    {
        [Key]
        public int Film_Id { get; set; }
        public int Vehicle_Id { get; set; }

        public virtual Film Film { get; set; }
        public virtual Vehicles Vehicle { get; set; }
    }
}
