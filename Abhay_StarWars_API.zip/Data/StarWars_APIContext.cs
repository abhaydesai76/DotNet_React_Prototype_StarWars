﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using StarWars_API.Models;
//using StarWars_API.Models;

namespace StarWars_API.Data
{
    public partial class StarWars_APIContext : DbContext
    {
        public StarWars_APIContext(DbContextOptions<StarWars_APIContext> options)
            : base(options)
        {
        }

        public DbSet<Film> Film { get; set; }
        public DbSet<People> People { get; set; }
        public DbSet<Planets> Planets { get; set; }
        public DbSet<Species> Species { get; set; }
        public DbSet<Starships> Starships { get; set; }
        public DbSet<Transports> Transports { get; set; }
        public DbSet<Vehicles> Vehicles { get; set; }
        public DbSet<FilmsCharacters> FilmsCharacters { get; set; }
        public DbSet<FilmsPlanets> FilmsPlanets { get; set; }
        public DbSet<FilmsSpecies> FilmsSpecies { get; set; }
        public DbSet<FilmsStarships> FilmsStarships { get; set; }
        public DbSet<FilmsVehicles> FilmsVehicles { get; set; }
        public DbSet<SpeciesPeople> SpeciesPeople { get; set; }
        public DbSet<StarshipsPilots> StarshipsPilots { get; set; }
        public DbSet<VehiclesPilots> VehiclesPilots { get; set; }        
        public DbSet<CharacterMaximumAppearance> CharacterMaximumAppearance { get; set; }
        public DbSet<SpeciesMaximumAppearance> SpeciesMaximumAppearance { get; set; }
        public DbSet<MostPilotPlanet> MostPilotPlanet { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<FilmsCharacters>()
            .HasKey(t => new { t.Film_Id, t.People_Id });

            modelBuilder.Entity<FilmsCharacters>()
                .HasOne(pt => pt.Film)
                .WithMany(p => p.FilmsCharacters)
                .HasForeignKey(pt => pt.Film_Id);

            modelBuilder.Entity<FilmsCharacters>()
                .HasOne(pt => pt.People)
                .WithMany(t => t.FilmsCharacters)
                .HasForeignKey(pt => pt.People_Id);

            modelBuilder.Entity<FilmsPlanets>()
                .HasKey(c => new { c.Film_Id, c.Planet_Id }); ;

            modelBuilder.Entity<FilmsPlanets>()
                .HasOne(pt => pt.Film)
                .WithMany(p => p.FilmsPlanets)
                .HasForeignKey(pt => pt.Film_Id);

            modelBuilder.Entity<FilmsPlanets>()
                .HasOne(pt => pt.Planet)
                .WithMany(t => t.FilmsPlanets)
                .HasForeignKey(pt => pt.Planet_Id);

            modelBuilder.Entity<FilmsSpecies>()
                .HasKey(c => new { c.Film_Id, c.Species_Id }); ;

            modelBuilder.Entity<FilmsSpecies>()
                .HasOne(pt => pt.Film)
                .WithMany(p => p.FilmsSpecies)
                .HasForeignKey(pt => pt.Film_Id);

            modelBuilder.Entity<FilmsSpecies>()
                .HasOne(pt => pt.Species)
                .WithMany(t => t.FilmsSpecies)
                .HasForeignKey(pt => pt.Species_Id);

            modelBuilder.Entity<FilmsStarships>()
                .HasKey(c => new { c.Film_Id, c.Starship_Id }); ;

            modelBuilder.Entity<FilmsStarships>()
                .HasOne(pt => pt.Film)
                .WithMany(p => p.FilmsStarships)
                .HasForeignKey(pt => pt.Film_Id);

            modelBuilder.Entity<FilmsStarships>()
                .HasOne(pt => pt.Starship)
                .WithMany(t => t.FilmsStarships)
                .HasForeignKey(pt => pt.Starship_Id);

            modelBuilder.Entity<FilmsVehicles>()
                .HasKey(c => new { c.Film_Id, c.Vehicle_Id }); ;

            modelBuilder.Entity<FilmsVehicles>()
                .HasOne(pt => pt.Film)
                .WithMany(p => p.FilmsVehicles)
                .HasForeignKey(pt => pt.Film_Id);

            modelBuilder.Entity<FilmsVehicles>()
                .HasOne(pt => pt.Vehicle)
                .WithMany(t => t.FilmsVehicles)
                .HasForeignKey(pt => pt.Vehicle_Id);

            modelBuilder.Entity<SpeciesPeople>()
                .HasKey(c => new { c.Species_Id, c.People_Id }); ;

            modelBuilder.Entity<SpeciesPeople>()
                .HasOne(pt => pt.Species)
                .WithMany(p => p.SpeciesPeople)
                .HasForeignKey(pt => pt.Species_Id);

            modelBuilder.Entity<SpeciesPeople>()
                .HasOne(pt => pt.People)
                .WithMany(t => t.SpeciesPeople)
                .HasForeignKey(pt => pt.People_Id);

            modelBuilder.Entity<StarshipsPilots>()
                .HasKey(c => new { c.Starship_Id, c.People_Id }); ;

            modelBuilder.Entity<StarshipsPilots>()
                .HasOne(pt => pt.Starship)
                .WithMany(p => p.StarshipsPilots)
                .HasForeignKey(pt => pt.Starship_Id);

            modelBuilder.Entity<StarshipsPilots>()
                .HasOne(pt => pt.People)
                .WithMany(t => t.StarshipsPilots)
                .HasForeignKey(pt => pt.People_Id);

            modelBuilder.Entity<VehiclesPilots>()
                .HasKey(c => new { c.Vehicle_Id, c.People_Id }); ;

            modelBuilder.Entity<VehiclesPilots>()
                .HasOne(pt => pt.Vehicle)
                .WithMany(p => p.VehiclesPilots)
                .HasForeignKey(pt => pt.Vehicle_Id);

            modelBuilder.Entity<VehiclesPilots>()
                .HasOne(pt => pt.People)
                .WithMany(t => t.VehiclesPilots)
                .HasForeignKey(pt => pt.People_Id);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
