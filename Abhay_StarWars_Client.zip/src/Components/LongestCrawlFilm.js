import React from 'react';
import axios from 'axios';

export default class LongestCrawlFilm extends React.Component {

    state = {
        // persons: [],
        longestopeningcrawlfilmname: []
    }

    componentDidMount() {
        this.getLongestFilm();
    } 

    async getLongestFilm() {
        await axios.get('http://localhost:50005/api/films/GetLongestCrawlFilm')
        .then(result => {
                let values =  result.data;
                console.log(result);
                // this.setState({persons: result.data});
                this.setState({longestopeningcrawlfilmname: result.data});
        })
        .catch(function (error) {
            if (error.response) {              
              console.log(error.response.data);
              console.log(error.response.status);              
            } else if (error.request) {              
              console.log(error.request);
            } else {              
              console.log('Error', error.message);
            }
        });
    }

    render() {

        return ( 
            <div> 
                {this.state.longestopeningcrawlfilmname.length === 0 ? ( 
                    <div>Loading...</div> 
                ) : ( 
                    this.state.longestopeningcrawlfilmname
                    ) 
                } 
            </div> 
        ); 
      } 


    // render() {
    //     return (

    //         // <ul>
    //         //     { this.state.persons.map(person => <li>{ person.name }</li>) }
    //         // </ul>
    //             this.state.longestopeningcrawlfilmname
    //         )
    // }
}