import React from 'react';
import axios from 'axios';

export default class MaximumCharacterAppearance extends React.Component {
    
    constructor(props) {
        super(props);
        this.state = { MaximumCharacterAppearance: [] }
    }    

    componentDidMount() {

        axios.get('http://localhost:50005/api/films/GetMaximumCharacterAppearance')
        .then(result => {                
                console.log(result);                                    
                this.setState({MaximumCharacterAppearance: result.data, loading: false});                
        })
        .catch(function (error) {
            if (error.response) {              
              console.log(error.response.data);
              console.log(error.response.status);              
            } else if (error.request) {              
              console.log(error.request);
            } else {              
              console.log('Error', error.message);
            }
        });
        }
        
        render() {
            return (   
                <React.Fragment>
                <div>  
                    {this.state.MaximumCharacterAppearance.length === 0 ? 
                    ( 
                        <div>Loading...</div> 
                    ) : 
                    ( 
                    <ul>
                        {
                            this.state.MaximumCharacterAppearance.map(character => 
                                (                                
                                    <li key={character.characterName}>{ character.characterName }  ({ character.noOfAppearnces })</li>                                 
                                )
                            )
                        }          
                    </ul>
                    )}
                </div> 
                </React.Fragment>                       
            )
        }    
}