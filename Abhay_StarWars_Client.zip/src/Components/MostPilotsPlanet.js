import React from 'react';
import axios from 'axios';

export default class MostPilotsPlanet extends React.Component {   
    
    constructor(props) {
        super(props);
        this.state = { MostPilotsPlanets: [] }
    }    

    componentDidMount() {

        axios.get('http://localhost:50005/api/films/GetMostPilotsPlanet')
            .then(result => {
                    console.log(result);                    
                    this.setState({MostPilotsPlanets: result.data});
            })
            .catch(function (error) {
                if (error.response) {              
                  console.log(error.response.data);
                  console.log(error.response.status);              
                } else if (error.request) {              
                  console.log(error.request);
                } else {              
                  console.log('Error', error.message);
                }
            });
        }

    
        render() {
            return (   
                <React.Fragment>
                <div>  
                    {this.state.MostPilotsPlanets.length === 0 ? 
                    ( 
                        <div>Loading...</div> 
                    ) : 
                    ( 
                    <ul>
                        {
                            this.state.MostPilotsPlanets.map(mostpilotsplanet => 
                                (                                
                                    <li key={mostpilotsplanet.planetId}>
                                        Planet: { mostpilotsplanet.planetName } - Pilots: ({ mostpilotsplanet.noOfPilots })
                                        { mostpilotsplanet.pilotName } - { mostpilotsplanet.speciesName },
                                    </li>                                 
                                )
                            )
                        }          
                    </ul>
                    )}
                </div> 
                </React.Fragment>                       
            )
        }
}