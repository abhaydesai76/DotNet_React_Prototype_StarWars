import React from 'react';
import './NotFound.css'
 
const notFound = (props) => {
    return (
        <p className={'notFound'}>
            "404 SORRY COULDN'T FIND IT!!!"
        </p>
    )
}
 
export default notFound;