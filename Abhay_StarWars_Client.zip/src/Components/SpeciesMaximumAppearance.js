import React from 'react';
import axios from 'axios';

export default class SpeciesMaximumAppearance extends React.Component {    
    
    constructor(props) {
        super(props);
        this.state = { SpeciesMaximumAppearance: [] }
    } 
    componentDidMount() {

        axios.get('http://localhost:50005/api/films/GetSpeciesMaximumAppearance')
            .then(result => {
                    console.log(result);                    
                    this.setState({SpeciesMaximumAppearance: result.data});
            })
            .catch(function (error) {
                if (error.response) {              
                  console.log(error.response.data);
                  console.log(error.response.status);              
                } else if (error.request) {              
                  console.log(error.request);
                } else {              
                  console.log('Error', error.message);
                }
            });
        }

    
        render() {
            return (   
                <React.Fragment>
                <div>  
                    {this.state.SpeciesMaximumAppearance.length === 0 ? 
                    ( 
                        <div>Loading...</div> 
                    ) : 
                    ( 
                    <ul>
                        {
                            this.state.SpeciesMaximumAppearance.map(species => 
                                (                                
                                    <li key={species.speciesId}>{ species.speciesName } ({ species.noOfAppearnces })</li>                                 
                                )
                            )
                        }          
                    </ul>
                    )}
                </div> 
                </React.Fragment>                       
            )
        }
}