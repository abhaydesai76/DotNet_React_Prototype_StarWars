import React, { Component } from 'react';
import { Container, Row, Button, Image, Table } from 'react-bootstrap';
import Ripples from 'react-ripples';
import LongestCrawlFilm from '../src/Components/LongestCrawlFilm';
import MaximumCharacterAppearance from '../src/Components/MaximumCharacterAppearance';
import SpeciesMaximumAppearance from '../src/Components/SpeciesMaximumAppearance';
import MostPilotsPlanet from '../src/Components/MostPilotsPlanet';
import logo from '../src/Resources/Star_Wars_Logo.svg';
import './App.css';
import '../src/Resources/Common.css';


    class App extends Component {
    
      handleClick() {
        console.log('I am not yet implemented', this);
        }

        render() {
            return (        
              <div>                
                <Container>
                  <p>
                    <img src={logo} alt="StarWars Test" class="center" width="200" ></img>  
                  </p>
                  <Ripples>
                    <Button>Do. Or do not. There is no try.</Button>
                  </Ripples>
                  <p>              
                  Which of all StarWars movies has longest opening crawl?
                  <Row><LongestCrawlFilm /></Row>                      
                  </p>   
                  <p>
                  What character(person) appeared in the most of StarWars films?
                  <Row><MaximumCharacterAppearance /></Row>                 
                  </p> 
                  <p>
                  What species appeared in the most number of StarWars films?
                  <Row><SpeciesMaximumAppearance /></Row>                
                  </p>
                  <p>
                  What planet in StarWars universe provided largest number of vehicle pilots?
                  <Row><MostPilotsPlanet class="center"/> </Row>                 
                  </p> 
                </Container>             
              </div>            
          )
        }              
  }

  export default App