import React, { Component } from 'react';
import { Container, Row, Button, Image, Table } from 'react-bootstrap';
import Ripples from 'react-ripples';
import LongestCrawlFilm from './Components/LongestCrawlFilm';
import MaximumCharacterAppearance from './Components/MaximumCharacterAppearance';
import SpeciesMaximumAppearance from './Components/SpeciesMaximumAppearance';
import MostPilotsPlanet from './Components/MostPilotsPlanet';
import StarWarslogo from '../src/Resources/Star_Wars_Logo.svg';
import Starlogo from '../src/Resources/Stars.svg';
import './App.css';
import '../src/Resources/Common.css';
import 'bootstrap/dist/css/bootstrap.min.css';


class App extends Component {

  constructor(props) {
    super(props);

    this.state = {
      showAnswer1: false,
      showAnswer2: false,
      showAnswer3: false,
      showAnswer4: false,
    }

    this.showResults =  this.showResults.bind(this);    
  } 

  showResults() {      
      this.setState({ showAnswer1: !this.state.showAnswer1 });
      this.setState({ showAnswer2: !this.state.showAnswer2 });
      this.setState({ showAnswer3: !this.state.showAnswer3 });
      this.setState({ showAnswer4: !this.state.showAnswer4 });      
  }

  render() {

    const { showAnswer1, showAnswer2, showAnswer3, showAnswer4 } = this.state;

      return (                
        <div style = {{textAlign: "center", border: "1"}}>                
          <Container>           
            <span>StarWars Test</span>
            <p>
            <img src={StarWarslogo} alt="StarWars Test" className="center" width="200" height="200"></img>  
            </p>  
            <Button variant="warning" className="button" onClick={this.showResults}>
                <img src={Starlogo} width="100" height="50"/>
                    <span><b>Do. Or do not. There is no try.</b></span>
                <img src={Starlogo} width="100" height="50"/>
            </Button>
            <p/>            
            <p>              
              Which of all StarWars movies has longest opening crawl?
            </p>             
              <span>{showAnswer1 && <LongestCrawlFilm />}</span>
            <p>
            <p />
              What character(person) appeared in the most of StarWars films?
            </p> 
              <span>{showAnswer2 && <MaximumCharacterAppearance />}</span>
            <p>
              What species appeared in the most number of StarWars films?
            </p>
              <span>{showAnswer3 && <SpeciesMaximumAppearance />}</span>
            <p>
              What planet in StarWars universe provided largest number of vehicle pilots?
            </p> 
              <span>{showAnswer4 && <MostPilotsPlanet />}</span>            
          </Container>            
        </div>            
    )
  }              
}

export default App